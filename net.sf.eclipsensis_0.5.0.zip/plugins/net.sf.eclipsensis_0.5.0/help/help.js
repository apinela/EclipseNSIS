<!--

// these are the scripts that are called in the links.
var ie = document.all;
var ns4 = document.layers;
var mozilla = document.getElementById;
var DHTML = (mozilla || ie || ns4);
var highlightColor = "rgb(153, 204, 204)";
var lastObj = null;
var lastObjBorder = null;

function highlightDef(id)
{
    if(DHTML) {
    	if(lastObj) {
    	    lastObj.style.border = lastObjBorder;
    	    lastObj = null;
    	    lastObjBorder = null;
    	}
    	lastObj = getObj(id);
    	if(lastObj) {
            lastObjBorder = lastObj.style.border;
            lastObj.style.border = "2px solid "+highlightColor;
        }
    }
}

function getObj(name)
{
    var temp = new makeObj(name);
    if(temp.obj) {
        return temp;
    }
    else {
        return null;
    }
}

function makeObj(name)
{
    if (document.getElementById)
    {
  	    this.obj = document.getElementById(name);
  	    if(this.obj) {
    	    this.style = this.obj.style;
        }
    }
    else if (document.all)
    {
	    this.obj = document.all[name];
  	    if(this.obj) {
    	    this.style = this.obj.style;
        }
    }
    else if (document.layers)
    {
   	    this.obj = document.layers[name];
   	    this.style = document.layers[name];
    }
}

function toggleImage(name, index, images)
{
    if(DHTML) {
        index = 1-index;
        document.images[name].src = images[index].src;
    }
    return index;
}

function changeCursor(id, cur)
{
    if(DHTML) {
        var obj = getObj(id);
        obj.style.cursor = cur;
    }
}

// -->
