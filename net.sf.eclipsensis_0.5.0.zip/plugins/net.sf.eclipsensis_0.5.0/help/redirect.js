<!--
function prependSlash(url)
{
    if(url && url.charAt(0) != '/') {
        url = "/" + url;
    }
    return url;
}

function redirectEclipse(url)
{
    document.location = "/help/topic" + prependSlash(url);
}

function redirectNSIS(url)
{
    document.location = "/help/topic/net.sf.eclipsensis/help/NSIS/Docs"+prependSlash(url);
}
//-->
